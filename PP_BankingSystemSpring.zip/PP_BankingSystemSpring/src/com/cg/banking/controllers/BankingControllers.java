package com.cg.banking.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Login;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.services.BankingServices;


@Controller
public class BankingControllers {
	
	@Autowired
	BankingServices services;

	public BankingServices getServices() {
		return services;
	}
	public void setServices(BankingServices services) {
		this.services = services;
	}
	
	@RequestMapping(value="Login", method=RequestMethod.GET)
	public String displayLoginPage(Model model) {
		Login log=new Login();
		model.addAttribute("log", log);
		model.addAttribute("compNameObj", "Login Page");
		return "login";
	}
	
	@RequestMapping(value="/ValidateUser", method=RequestMethod.POST)
	public String validateUser(@ModelAttribute(value="log") 
	@Valid Login log,BindingResult result,Model model) {
		Account account=new Account();
		model.addAttribute("log", log);
		model.addAttribute("compNameObj", "Banking Portal");
		if(log.getUsername().equals(account.getAccountNo())&&log.getPassword().equals(account.getPinNumber()));
			return "Menu";
	}
	
	/*Register*/
	@RequestMapping(value = "Register", method = RequestMethod.GET)
	public String displayAddTraineePage(@ModelAttribute(value="cust") @Valid Customer customer,Model model,BindingResult result) {
		model.addAttribute("customer", new Customer());
		return "Register";
	}
	
	
	
	@RequestMapping(value="OpenAccount", method=RequestMethod.POST)
	public String displayOpenAccount(@ModelAttribute(value="acc") @Valid Account account,BindingResult result,Model model) throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		model.addAttribute("acc", new Account());
		return "OpenAccPage";
	}
	
	@RequestMapping(value="AcceptAccountDetails", method=RequestMethod.POST)
	public String acceptAccountDetails(@ModelAttribute(value="acc") @Valid Account account, BindingResult result,Model model) throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		Account acnt = services.openAccount(account.getCustomer().getCustName(), account.getCustomer().getCustAddress(), account.getCustomer().getMobNo(), account.getAccountType(), account.getAccountBalance(),account.getAccountNo(),account.getPinNumber());
		model.addAttribute("account", acnt);
		return "AccountOpenSuccess";
	}
	
	
}
