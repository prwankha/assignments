package com.cg.banking.beans;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotEmpty;
@Entity
@Table(name="dg_users")
public class Login {
	@Id
	@Column(name="user_name",length=20)
	private String username;
	@Column(name="password",length=20)
	private String password;
	public Login() {}
	public Login(String username, String password) {
		super();
		this.username = username;
		this.password = password;
	}
	@NotEmpty(message="UserName is mandatory")
	@Size(min=5,message="Min 5 char require in username require")
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	@NotEmpty(message="Password is mandatory")
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
} 
